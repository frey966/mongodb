package com.lagou;

import com.lagou.bean.Resume;
import com.lagou.repository.ResumeRepository;
import com.lagou.repository.StudentRepository;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class MongoRepositoryMain {
    public static void main(String[] args) {
        SpringApplication.run(MongoRepositoryMain.class, args);
    }

    public void studentFindAll() {
        ApplicationContext applicationContext = SpringApplication.run(MongoRepositoryMain.class);
        StudentRepository studentRepository = applicationContext.getBean(StudentRepository.class);
        System.out.println(studentRepository.findAll());
    }

    public void resume(){
        ApplicationContext applicationContext = SpringApplication.run(MongoRepositoryMain.class);
        ResumeRepository resumeRepository = applicationContext.getBean(ResumeRepository.class);
        System.out.println(resumeRepository.findAll());
//        System.out.println(resumeRepository.findByNameEquals("zhangsan"));
//        System.out.println(resumeRepository.findByNameAndExpectSalary("zhangsan",25000));
        Resume resume  = new Resume();
        resume.setName("liuxiaosong2");
        resume.setExpectSalary(1);
        resume.setCity("shanghai2");
        resumeRepository.save(resume);
    }
}
