package com.lagou.dao;

import com.lagou.bean.Student;

/**
 * @author 15579
 * 2019/6/13 14:28
 * 文件说明：
 */
public interface StudentDao extends MongodbBaseDao<Student,String>  {

}

